function checkSock(array) {
  var numCo = {}; //variabel untuk menghitung jumlah angka sama di array
  var sockCo = 0; //variabel untuk menghitung jumlah variabel numCo dengan denominator 2
  array.forEach((el) => {
    numCo[el] = numCo[el] ? numCo[el] + 1 : 1;
    if (numCo[el] % 2 === 0) {
      //menghitung jumlah angka sama dengan denominator 2
      sockCo++;
    }
  });
  return console.log(sockCo);
}

checkSock([5, 7, 7, 9, 10, 4, 5, 10, 6, 5]); //Contoh Soal
checkSock([10, 20, 20, 10, 10, 30, 50, 10, 20]); //Soal a
checkSock([6, 5, 2, 3, 5, 2, 2, 1, 1, 5, 1, 3, 3, 3, 5]); //Soal b
checkSock([1, 1, 3, 1, 2, 1, 3, 3, 3, 3]); //Soal c
