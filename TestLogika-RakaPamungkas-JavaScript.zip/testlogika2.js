function checkSentence(string) {
  var array = string.split(" "); //variabel untuk mengkonversi masukkan function menjadi array
  var pattern = /[`!@#$%^&*()_+\=\[\]{};':"\\|<>\/~]/; //pola special character yang dijadikan pedoman penggunaan
  var newArr = []; //variabel array baru untuk menyimpan string yang tidak mengandung special character
  for (var i = 0; i < array.length; i++) {
    if (pattern.test(array[i]) === false) {
      //memasukkan string yang tidak mengandung special character ke variabel newArr
      newArr.push(array[i]);
    }
  }
  //return panjang Array dari variabel newArr
  return console.log(newArr.length);
}

checkSentence("Kemarin Shopia per[gi ke mall."); //Contol Soal
checkSentence("Saat meng*ecat tembok, Agung dib_antu oleh Raihan."); //Soal a
checkSentence("Berapa u(mur minimal[ untuk !mengurus ktp?"); //Soal b
checkSentence("Masing-masing anak mendap(atkan uang jajan ya=ng be&rbeda."); //Soal c
